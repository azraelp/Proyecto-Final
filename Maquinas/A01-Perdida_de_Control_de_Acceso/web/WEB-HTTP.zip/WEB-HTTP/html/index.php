<!DOCTYPE html>
<html>
   <body>
   <?php
        header("Location:pagines/home.php");
        exit();
    ?>
   </body>
   <p>Que intentaves?</p>
</html>
