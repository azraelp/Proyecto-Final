<?php
$iPass = '1271';
echo $iPass;
echo "<br/>";
$sPassword = password_hash ("1271", PASSWORD_DEFAULT);
echo $sPassword;

// $oPassword = '$2y$10$eEGhR8r08uClNHjkOx6Jo.5me.nQg2QQuY4JGKTOhmSwqMBbJhci6';

echo "<br/>";
if (password_verify($sPassword,$oPassword)) {
  echo "True";
} else {
  echo "False";
};
?>
<!DOCTYPE html>
