<?php

$SERVER_NAME='localhost';
$USER_DB='root';
$PASS_DB='1271';
$DB_NAME='webs';
$DB_PORT=3306;

