<!DOCTYPE html>
<html>
   <body>
   <?php
        header("Location:../index.php");
        exit();
    ?>
   </body>
   <p>Que intentaves?</p>
</html>